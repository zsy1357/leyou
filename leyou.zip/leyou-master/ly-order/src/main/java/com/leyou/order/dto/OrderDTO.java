package com.leyou.order.dto;

import com.leyou.common.dto.CartDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * dto: orderDataTransferObject
 * 三个字段正好对应前端页面http://api.leyou.com/api/order-service/order 的三个字段
 * carts又是一个集合  包含了商品信息，所以又定义一个cartDTO
 */

@Data

public class OrderDTO {

    @NotNull
    private Long addressId; // 收获人地址id

    private Integer paymentType;// 付款类型

    private List<CartDTO> carts;// 订单详情

    public Long getAddressId() {
        return addressId;
    }

    public void setAddressId(Long addressId) {
        this.addressId = addressId;
    }

    public Integer getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(Integer paymentType) {
        this.paymentType = paymentType;
    }

    public List<CartDTO> getCarts() {
        return carts;
    }

    public void setCarts(List<CartDTO> carts) {
        this.carts = carts;
    }

    public OrderDTO() {
    }

    public OrderDTO(@NotNull Long addressId, Integer paymentType, List<CartDTO> carts) {
        this.addressId = addressId;
        this.paymentType = paymentType;
        this.carts = carts;
    }
}