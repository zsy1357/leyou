package com.leyou.item.mapper;

import com.leyou.common.mapper.BaseMapper;
import com.leyou.item.pojo.SpuDetail;

public interface SpuDetailMapper extends BaseMapper<SpuDetail> {
}
