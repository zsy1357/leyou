package com.leyou.auth.utils;

public abstract class JwtConstans {
    public static final String JWT_KEY_ID = "id";
    public static final String JWT_KEY_USER_NAME = "username";

    public static String getJwtKeyId() {
        return JWT_KEY_ID;
    }

    public static String getJwtKeyUserName() {
        return JWT_KEY_USER_NAME;
    }

    public JwtConstans() {
    }
}